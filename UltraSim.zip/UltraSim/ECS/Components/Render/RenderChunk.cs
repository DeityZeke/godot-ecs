#nullable enable

namespace UltraSim.ECS.Components
{
    /// <summary>
    /// Links a chunk entity to its Godot rendering node(s).
    /// Stores NodePath instead of direct reference to maintain engine independence.
    /// Client-side renderer resolves paths to actual Godot nodes.
    /// </summary>
    public struct RenderChunk
    {
        /// <summary>
        /// Godot NodePath to the rendering node (MeshInstance3D, MultiMeshInstance3D, etc.).
        /// Empty string if not currently instantiated.
        /// </summary>
        public string NodePath;

        /// <summary>
        /// Number of entities currently rendered in this chunk.
        /// Used for MultiMesh capacity management.
        /// </summary>
        public int RenderedEntityCount;

        /// <summary>
        /// Whether the chunk's render node is currently visible in the scene tree.
        /// False when culled or zone is None.
        /// </summary>
        public bool IsVisible;

        public RenderChunk(string nodePath, int entityCount, bool isVisible)
        {
            NodePath = nodePath;
            RenderedEntityCount = entityCount;
            IsVisible = isVisible;
        }

        public bool HasNode => !string.IsNullOrEmpty(NodePath);

        public override string ToString()
            => HasNode
                ? $"RenderChunk[{NodePath}, Entities:{RenderedEntityCount}, Visible:{IsVisible}]"
                : "RenderChunk[No Node]";
    }
}
