#nullable enable

namespace UltraSim.ECS.Components
{
    /// <summary>
    /// Defines which render zone a chunk belongs to based on distance from camera.
    /// Core = MeshInstance3D (full interactivity), Near = MultiMesh (visual only), Far = Billboards (optional).
    /// </summary>
    public enum RenderZoneType : byte
    {
        /// <summary>
        /// Not currently being rendered (outside all zones or culled).
        /// </summary>
        None = 0,

        /// <summary>
        /// Core bubble around camera - individual MeshInstance3D per chunk.
        /// Provides full interactivity, no hitching on chunk transitions.
        /// Default: 3x3x3 or 5x5x5 chunks around camera.
        /// </summary>
        Core = 1,

        /// <summary>
        /// Near zone beyond core bubble - MultiMesh batching per chunk.
        /// Visual only, highly efficient batched rendering.
        /// Distance configurable like Minecraft render distance.
        /// </summary>
        Near = 2,

        /// <summary>
        /// Far zone - optional billboard/impostor rendering.
        /// Ultra low-res, only if profiling shows need.
        /// Typically 2x the core bubble distance.
        /// </summary>
        Far = 3
    }

    /// <summary>
    /// Marks which render zone a chunk is currently assigned to.
    /// Updated by HybridRenderSystem based on camera position.
    /// </summary>
    public struct RenderZone
    {
        /// <summary>
        /// Current rendering zone for this chunk.
        /// </summary>
        public RenderZoneType Zone;

        /// <summary>
        /// Frame when this zone assignment was last updated.
        /// Used to detect stale assignments.
        /// </summary>
        public ulong LastUpdateFrame;

        public RenderZone(RenderZoneType zone, ulong frame)
        {
            Zone = zone;
            LastUpdateFrame = frame;
        }

        public bool IsRendered => Zone != RenderZoneType.None;

        public override string ToString()
            => $"RenderZone[{Zone}, Frame:{LastUpdateFrame}]";
    }
}
